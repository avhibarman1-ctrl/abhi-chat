package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.unwrapFirestoreError
import com.example.data.model.AppNotification
import com.example.data.model.AudiencePrivacy
import com.example.data.model.BlockedUser
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.CallType
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.FriendEdge
import com.example.data.model.FriendRequestItem
import com.example.data.model.GroupChat
import com.example.data.model.GroupMember
import com.example.data.model.MessageType
import com.example.data.model.PrivacyLevel
import com.example.data.model.PrivacySettings
import com.example.data.model.StatusItem
import com.example.data.model.StatusView
import com.example.data.model.StoryItem
import com.example.data.model.StoryView
import com.example.data.model.UserProfile
import com.example.data.repository.ChatGroupRepository
import com.example.data.repository.StatusStoryRepository
import com.example.data.repository.UserPrivacyRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class ActiveConversationKey(
    val chatId: String,
    val conversationType: String // "DIRECT" or "GROUP"
)

class AbhiChatViewModel(
    private val userRepo: UserPrivacyRepository,
    private val chatRepo: ChatGroupRepository,
    private val statusStoryRepo: StatusStoryRepository,
    val currentUserId: String
) : ViewModel() {

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val events = _events.asSharedFlow()

    private val _activeConversation = MutableStateFlow<ActiveConversationKey?>(null)
    val activeConversation = _activeConversation.asStateFlow()

    private val _targetUserPrivacy = MutableStateFlow<Map<String, PrivacySettings>>(emptyMap())
    val targetUserPrivacy = _targetUserPrivacy.asStateFlow()

    private val _liveLocationMessageId = MutableStateFlow<String?>(null)
    val liveLocationMessageId = _liveLocationMessageId.asStateFlow()

    init {
        viewModelScope.launch {
            userRepo.ensureCurrentUserInitialized()
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to initialize profile") }
            statusStoryRepo.cleanupExpiredOwnItems(currentUserId)
        }
    }

    private fun <T> Flow<T>.toUiState(tag: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(tag, "Stream error", root)
                emit(UiState.Error(root.localizedMessage ?: "Sync error"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val myProfile: StateFlow<UiState<UserProfile?>> =
        userRepo.observeMyProfile(currentUserId).toUiState("MyProfileVM")

    val myPrivacySettings: StateFlow<UiState<PrivacySettings?>> =
        userRepo.observeMyPrivacySettings(currentUserId).toUiState("PrivacyVM")

    val discoverableUsers: StateFlow<UiState<List<UserProfile>>> =
        userRepo.observeDiscoverableUsers(currentUserId).toUiState("UsersVM")

    val chats: StateFlow<UiState<List<ChatRoom>>> =
        chatRepo.observeChats(currentUserId).toUiState("ChatsVM")

    val groups: StateFlow<UiState<List<GroupChat>>> =
        chatRepo.observeGroups(currentUserId).toUiState("GroupsVM")

    val friends: StateFlow<UiState<List<FriendEdge>>> =
        userRepo.observeFriends(currentUserId).toUiState("FriendsVM")

    val friendRequests: StateFlow<UiState<List<FriendRequestItem>>> =
        userRepo.observeFriendRequests(currentUserId).toUiState("FriendReqVM")

    val blockedUsers: StateFlow<UiState<List<BlockedUser>>> =
        userRepo.observeBlockedUsers(currentUserId).toUiState("BlockedVM")

    val statuses: StateFlow<UiState<List<StatusItem>>> =
        statusStoryRepo.observeActiveStatuses(currentUserId).toUiState("StatusVM")

    val statusViews: StateFlow<UiState<List<StatusView>>> =
        statusStoryRepo.observeMyStatusViewReceipts(currentUserId).toUiState("StatusViewsVM")

    val stories: StateFlow<UiState<List<StoryItem>>> =
        statusStoryRepo.observeActiveStories(currentUserId).toUiState("StoriesVM")

    val storyViews: StateFlow<UiState<List<StoryView>>> =
        statusStoryRepo.observeStoryViewReceipts(currentUserId).toUiState("StoryViewsVM")

    val notifications: StateFlow<UiState<List<AppNotification>>> =
        userRepo.observeNotifications(currentUserId).toUiState("NotifVM")

    val calls: StateFlow<UiState<List<CallSession>>> =
        chatRepo.observeCalls(currentUserId).toUiState("CallsVM")

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeMessages: StateFlow<UiState<List<ChatMessage>>> =
        _activeConversation.flatMapLatest { key ->
            if (key == null) flowOf(emptyList())
            else chatRepo.observeMessages(key.chatId, currentUserId)
        }.toUiState("ActiveMessagesVM")

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeGroupMembers: StateFlow<UiState<List<GroupMember>>> =
        _activeConversation.flatMapLatest { key ->
            if (key == null || key.conversationType != "GROUP") flowOf(emptyList())
            else chatRepo.observeGroupMembers(key.chatId, currentUserId)
        }.toUiState("GroupMembersVM")

    fun openConversation(chatId: String, type: String) {
        _activeConversation.value = ActiveConversationKey(chatId, type)
    }

    fun closeConversation() {
        _activeConversation.value = null
    }

    fun fetchTargetPrivacy(targetUserId: String) {
        if (_targetUserPrivacy.value.containsKey(targetUserId)) return
        viewModelScope.launch {
            userRepo.getPrivacySettingsForUser(targetUserId)?.let { settings ->
                _targetUserPrivacy.value = _targetUserPrivacy.value + (targetUserId to settings)
            }
        }
    }

    private fun currentUserProfileOrFallback(): UserProfile {
        val state = myProfile.value
        return (state as? UiState.Success)?.data ?: UserProfile(
            id = currentUserId,
            userId = currentUserId,
            displayName = "Abhi User",
            username = "user_${currentUserId.take(4)}"
        )
    }

    private fun friendIdSet(): Set<String> {
        val list = (friends.value as? UiState.Success)?.data ?: emptyList()
        return list.flatMap { it.participantIds }.filter { it != currentUserId }.toSet()
    }

    private fun emitMessage(msg: String) {
        _events.tryEmit(msg)
    }

    // --- PROFILE & PRIVACY ---

    fun updateProfile(displayName: String, username: String, bio: String, avatarUrl: String?) {
        viewModelScope.launch {
            userRepo.updateProfile(displayName, username, bio, avatarUrl)
                .onSuccess { emitMessage("Profile updated") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to update profile") }
        }
    }

    fun updatePrivacySettings(settings: PrivacySettings) {
        viewModelScope.launch {
            userRepo.updatePrivacySettings(settings)
                .onSuccess { emitMessage("Privacy settings saved") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to save privacy settings") }
        }
    }

    fun setOnlineStatus(online: Boolean) {
        viewModelScope.launch {
            userRepo.setOnlineStatus(online)
        }
    }

    suspend fun prepareSignOut() {
        userRepo.setOnlineStatus(false)
    }

    // --- DIRECT & GROUP CHATS ---

    fun startDirectChat(otherUser: UserProfile, onOpened: (String) -> Unit) {
        viewModelScope.launch {
            val blocked = (blockedUsers.value as? UiState.Success)?.data.orEmpty().any { it.blockedId == otherUser.userId }
            if (blocked) {
                emitMessage("Unblock ${otherUser.displayName} first to send messages.")
                return@launch
            }
            if (userRepo.isBlockedByTarget(otherUser.userId)) {
                emitMessage("You cannot message this user.")
                return@launch
            }
            chatRepo.getOrCreateDirectChat(
                currentUser = currentUserProfileOrFallback(),
                otherUser = otherUser,
                isFriend = friendIdSet().contains(otherUser.userId)
            ).onSuccess { chatId ->
                openConversation(chatId, "DIRECT")
                onOpened(chatId)
            }.onFailure {
                emitMessage(it.localizedMessage ?: "Could not open chat")
            }
        }
    }

    fun createGroup(
        name: String,
        description: String,
        photoData: String,
        selectedMembers: List<UserProfile>,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            chatRepo.createGroup(
                name = name,
                description = description,
                photoData = photoData,
                creator = currentUserProfileOrFallback(),
                selectedMembers = selectedMembers
            ).onSuccess { groupId ->
                emitMessage("Group created")
                openConversation(groupId, "GROUP")
                onCreated(groupId)
            }.onFailure {
                emitMessage(it.localizedMessage ?: "Could not create group")
            }
        }
    }

    fun updateGroupInfo(groupId: String, name: String, description: String, photoData: String?) {
        viewModelScope.launch {
            chatRepo.updateGroupInfo(groupId, name, description, photoData)
                .onSuccess { emitMessage("Group info updated") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to update group") }
        }
    }

    fun addGroupMember(group: GroupChat, user: UserProfile) {
        viewModelScope.launch {
            chatRepo.addGroupMember(group, user, currentUserProfileOrFallback().displayName)
                .onSuccess { emitMessage("${user.displayName} added to group") }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not add member") }
        }
    }

    fun removeGroupMember(group: GroupChat, targetUserId: String) {
        viewModelScope.launch {
            chatRepo.removeGroupMember(group, targetUserId)
                .onSuccess { emitMessage("Member removed") }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not remove member") }
        }
    }

    fun toggleGroupAdmin(group: GroupChat, targetUserId: String, makeAdmin: Boolean) {
        viewModelScope.launch {
            chatRepo.toggleGroupAdmin(group, targetUserId, makeAdmin)
                .onSuccess { emitMessage(if (makeAdmin) "Promoted to Admin" else "Removed Admin role") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to update role") }
        }
    }

    fun leaveGroup(group: GroupChat, onLeft: () -> Unit) {
        viewModelScope.launch {
            chatRepo.leaveGroup(group)
                .onSuccess {
                    emitMessage("Left group")
                    closeConversation()
                    onLeft()
                }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to leave group") }
        }
    }

    // --- MESSAGES (SEND, EDIT, DELETE, REPLY, FORWARD, LIVE LOCATION) ---

    fun sendTextMessage(
        chatId: String,
        conversationType: String,
        recipientId: String,
        memberIds: List<String>,
        text: String,
        replyTo: ChatMessage? = null,
        groupName: String = ""
    ) {
        if (text.isBlank()) return
        viewModelScope.launch {
            chatRepo.sendMessage(
                chatId = chatId,
                conversationType = conversationType,
                sender = currentUserProfileOrFallback(),
                recipientId = recipientId,
                memberIds = memberIds,
                text = text,
                messageType = MessageType.TEXT,
                replyTo = replyTo,
                groupName = groupName
            ).onFailure { emitMessage(it.localizedMessage ?: "Message failed to send") }
        }
    }

    fun sendMediaMessage(
        chatId: String,
        conversationType: String,
        recipientId: String,
        memberIds: List<String>,
        mediaType: MessageType,
        mediaData: String,
        durationSec: Long,
        caption: String,
        replyTo: ChatMessage? = null,
        groupName: String = ""
    ) {
        viewModelScope.launch {
            chatRepo.sendMessage(
                chatId = chatId,
                conversationType = conversationType,
                sender = currentUserProfileOrFallback(),
                recipientId = recipientId,
                memberIds = memberIds,
                text = caption,
                messageType = mediaType,
                mediaData = mediaData,
                mediaDurationSec = durationSec,
                replyTo = replyTo,
                groupName = groupName
            ).onFailure { emitMessage(it.localizedMessage ?: "Failed to send media") }
        }
    }

    fun sendLocationMessage(
        chatId: String,
        conversationType: String,
        recipientId: String,
        memberIds: List<String>,
        lat: Double,
        lng: Double,
        isLive: Boolean,
        groupName: String = ""
    ) {
        viewModelScope.launch {
            chatRepo.sendMessage(
                chatId = chatId,
                conversationType = conversationType,
                sender = currentUserProfileOrFallback(),
                recipientId = recipientId,
                memberIds = memberIds,
                text = if (isLive) "Sharing live location" else "Shared current location",
                messageType = MessageType.LOCATION,
                locationLat = lat,
                locationLng = lng,
                locationLive = isLive,
                groupName = groupName
            ).onSuccess { msgId ->
                if (isLive) _liveLocationMessageId.value = msgId
                emitMessage(if (isLive) "Live location sharing started" else "Location shared")
            }.onFailure { emitMessage(it.localizedMessage ?: "Failed to share location") }
        }
    }

    fun updateLiveLocationCoordinates(messageId: String, lat: Double, lng: Double) {
        viewModelScope.launch {
            chatRepo.updateLiveLocationMessage(messageId, lat, lng, isLive = true)
        }
    }

    fun stopLiveLocation(messageId: String, lat: Double, lng: Double) {
        viewModelScope.launch {
            chatRepo.updateLiveLocationMessage(messageId, lat, lng, isLive = false)
                .onSuccess {
                    if (_liveLocationMessageId.value == messageId) _liveLocationMessageId.value = null
                    emitMessage("Live location sharing stopped")
                }
        }
    }

    fun editMessage(messageId: String, newText: String) {
        viewModelScope.launch {
            chatRepo.editMessage(messageId, newText)
                .onSuccess { emitMessage("Message edited") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to edit message") }
        }
    }

    fun deleteMessageForMe(message: ChatMessage) {
        viewModelScope.launch {
            chatRepo.deleteMessageForMe(message)
                .onSuccess { emitMessage("Deleted for you") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to delete message") }
        }
    }

    fun deleteMessageForEveryone(messageId: String) {
        viewModelScope.launch {
            chatRepo.deleteMessageForEveryone(messageId)
                .onSuccess { emitMessage("Deleted for everyone") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to delete message") }
        }
    }

    fun forwardMessage(
        original: ChatMessage,
        targetUsers: List<UserProfile>,
        targetGroups: List<GroupChat>
    ) {
        viewModelScope.launch {
            chatRepo.forwardMessageToMultipleTargets(
                original = original,
                sender = currentUserProfileOrFallback(),
                targetUsers = targetUsers,
                targetGroups = targetGroups,
                friendUserIds = friendIdSet()
            ).onSuccess { count ->
                emitMessage("Forwarded to $count conversation${if (count == 1) "" else "s"}")
            }.onFailure {
                emitMessage(it.localizedMessage ?: "Failed to forward message")
            }
        }
    }

    // --- WHATSAPP STATUSES ---

    fun postStatus(
        mediaType: String,
        text: String,
        bgHex: String,
        mediaData: String,
        privacy: AudiencePrivacy
    ) {
        viewModelScope.launch {
            statusStoryRepo.postStatus(
                user = currentUserProfileOrFallback(),
                mediaType = mediaType,
                text = text,
                backgroundColorHex = bgHex,
                mediaData = mediaData,
                privacy = privacy,
                friendIds = friendIdSet().toList()
            ).onSuccess { emitMessage("Status posted (expires in 24h)") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to post status") }
        }
    }

    fun markStatusViewed(status: StatusItem) {
        viewModelScope.launch {
            statusStoryRepo.markStatusViewed(status, currentUserProfileOrFallback())
        }
    }

    fun replyToStatus(status: StatusItem, replyText: String, onOpenChat: (String) -> Unit) {
        if (replyText.isBlank()) return
        viewModelScope.launch {
            val owner = (discoverableUsers.value as? UiState.Success)?.data
                ?.firstOrNull { it.userId == status.userId }
                ?: UserProfile(id = status.userId, userId = status.userId, displayName = status.userName, avatarUrl = status.userAvatarUrl)
            chatRepo.getOrCreateDirectChat(
                currentUser = currentUserProfileOrFallback(),
                otherUser = owner,
                isFriend = friendIdSet().contains(owner.userId)
            ).onSuccess { chatId ->
                chatRepo.sendMessage(
                    chatId = chatId,
                    conversationType = "DIRECT",
                    sender = currentUserProfileOrFallback(),
                    recipientId = owner.userId,
                    memberIds = listOf(currentUserId, owner.userId),
                    text = "Status reply (${status.text.take(40)}): $replyText",
                    messageType = MessageType.TEXT
                )
                emitMessage("Status reply sent")
                onOpenChat(chatId)
            }.onFailure {
                emitMessage(it.localizedMessage ?: "Could not reply to status")
            }
        }
    }

    fun deleteStatus(statusId: String) {
        viewModelScope.launch {
            statusStoryRepo.deleteStatus(statusId)
                .onSuccess { emitMessage("Status deleted") }
        }
    }

    // --- FACEBOOK STORIES ---

    fun postStory(
        mediaType: String,
        caption: String,
        overlayText: String,
        bgHex: String,
        mediaData: String,
        privacy: AudiencePrivacy
    ) {
        viewModelScope.launch {
            statusStoryRepo.postStory(
                user = currentUserProfileOrFallback(),
                mediaType = mediaType,
                caption = caption,
                overlayText = overlayText,
                backgroundColorHex = bgHex,
                mediaData = mediaData,
                privacy = privacy,
                friendIds = friendIdSet().toList()
            ).onSuccess { emitMessage("Story shared (24h)") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to share story") }
        }
    }

    fun markStoryViewed(story: StoryItem) {
        viewModelScope.launch {
            statusStoryRepo.markStoryViewed(story, currentUserProfileOrFallback())
        }
    }

    fun reactToStory(story: StoryItem, emoji: String) {
        viewModelScope.launch {
            statusStoryRepo.reactToStory(story, currentUserProfileOrFallback(), emoji)
                .onFailure { emitMessage(it.localizedMessage ?: "Could not react") }
        }
    }

    fun replyToStory(story: StoryItem, replyText: String) {
        viewModelScope.launch {
            statusStoryRepo.replyToStory(story, currentUserProfileOrFallback(), replyText)
                .onSuccess { emitMessage("Story reply sent") }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not reply to story") }
        }
    }

    fun deleteStory(storyId: String) {
        viewModelScope.launch {
            statusStoryRepo.deleteStory(storyId)
                .onSuccess { emitMessage("Story deleted") }
        }
    }

    // --- FRIEND REQUESTS, BLOCK & REPORT ---

    fun sendFriendRequest(receiver: UserProfile) {
        viewModelScope.launch {
            userRepo.sendFriendRequest(currentUserProfileOrFallback(), receiver)
                .onSuccess { emitMessage("Friend request sent to ${receiver.displayName}") }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not send request") }
        }
    }

    fun acceptFriendRequest(request: FriendRequestItem) {
        viewModelScope.launch {
            userRepo.acceptFriendRequest(request)
                .onSuccess { emitMessage("You are now friends with ${request.senderName}") }
                .onFailure { emitMessage(it.localizedMessage ?: "Failed to accept request") }
        }
    }

    fun rejectFriendRequest(requestId: String) {
        viewModelScope.launch {
            userRepo.rejectFriendRequest(requestId)
                .onSuccess { emitMessage("Friend request declined") }
        }
    }

    fun cancelFriendRequest(requestId: String) {
        viewModelScope.launch {
            userRepo.cancelFriendRequest(requestId)
                .onSuccess { emitMessage("Friend request cancelled") }
        }
    }

    fun removeFriend(friendEdgeId: String) {
        viewModelScope.launch {
            userRepo.removeFriend(friendEdgeId)
                .onSuccess { emitMessage("Friend removed") }
        }
    }

    fun blockUser(target: UserProfile, reason: String = "Blocked by user") {
        viewModelScope.launch {
            userRepo.blockUser(target, reason)
                .onSuccess { emitMessage("${target.displayName} has been blocked") }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not block user") }
        }
    }

    fun unblockUser(targetUserId: String) {
        viewModelScope.launch {
            userRepo.unblockUser(targetUserId)
                .onSuccess { emitMessage("User unblocked") }
        }
    }

    fun reportUser(target: UserProfile, reason: String, details: String, alsoBlock: Boolean) {
        viewModelScope.launch {
            userRepo.reportUser(target, reason, details)
                .onSuccess {
                    if (alsoBlock) {
                        userRepo.blockUser(target, reason)
                    }
                    emitMessage("Report submitted securely")
                }
                .onFailure { emitMessage(it.localizedMessage ?: "Could not submit report") }
        }
    }

    // --- NOTIFICATIONS ---

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            userRepo.markNotificationRead(notificationId)
        }
    }

    fun markAllNotificationsRead(list: List<AppNotification>) {
        viewModelScope.launch {
            userRepo.markAllNotificationsRead(list)
                .onSuccess { emitMessage("All notifications marked as read") }
        }
    }

    // --- VOICE & VIDEO CALLS ---

    fun startCall(callee: UserProfile, callType: CallType) {
        viewModelScope.launch {
            val blocked = (blockedUsers.value as? UiState.Success)?.data.orEmpty().any { it.blockedId == callee.userId }
            if (blocked || userRepo.isBlockedByTarget(callee.userId)) {
                emitMessage("Calls are blocked between you and ${callee.displayName}.")
                return@launch
            }
            chatRepo.startCall(currentUserProfileOrFallback(), callee, callType)
                .onFailure { emitMessage(it.localizedMessage ?: "Could not place call") }
        }
    }

    fun acceptCall(callId: String) {
        viewModelScope.launch {
            chatRepo.updateCallStatus(callId, CallStatus.ACTIVE)
        }
    }

    fun endCall(callId: String, rejected: Boolean = false) {
        viewModelScope.launch {
            chatRepo.updateCallStatus(callId, if (rejected) CallStatus.REJECTED else CallStatus.ENDED)
        }
    }

    // --- PRIVACY FILTER HELPERS ---

    fun canViewField(targetUserId: String, privacyField: String): Boolean {
        if (targetUserId == currentUserId) return true
        val level = PrivacyLevel.fromRaw(privacyField)
        return when (level) {
            PrivacyLevel.EVERYONE -> true
            PrivacyLevel.FRIENDS -> friendIdSet().contains(targetUserId)
            PrivacyLevel.NOBODY -> false
        }
    }
}
