package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.BlockedUser
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.FriendEdge
import com.example.data.model.FriendRequestItem
import com.example.data.model.GroupChat
import com.example.data.model.MessageType
import com.example.data.model.PrivacySettings
import com.example.data.model.StatusItem
import com.example.data.model.StoryItem
import com.example.data.model.UserProfile
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsListScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.ProfilePrivacyScreen
import com.example.ui.screens.UpdatesScreen
import com.example.ui.theme.AbhiChatTheme
import com.example.ui.viewmodel.UiState
import android.app.Activity
import android.content.ContextWrapper
import com.example.data.firebase.findActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private val currentUid = "uid_alice"
    private val sampleUsers = listOf(
        UserProfile(id = "uid_alice", userId = "uid_alice", displayName = "Alice", username = "alice", online = true),
        UserProfile(id = "uid_bob", userId = "uid_bob", displayName = "Bob Sharma", username = "bob", online = true, hasActiveStory = true)
    )

    @Test
    fun `read app name is ABHI CHAT`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ABHI CHAT", appName)
    }

    @Test
    fun `auth screen renders branding and sign in button`() {
        composeTestRule.setContent {
            AbhiChatTheme {
                AuthScreen(onAuthSuccess = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ABHI CHAT").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("google_sign_in_button").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `findActivity unwraps nested ContextWrappers and default_web_client_id is configured`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java)
        val activity = controller.get()
        val wrappedOnce = ContextWrapper(activity)
        val wrappedTwice = ContextWrapper(wrappedOnce)

        assertSame(activity, wrappedTwice.findActivity())

        val webClientId = activity.getString(R.string.default_web_client_id)
        assertNotNull(webClientId)
        assertTrue(webClientId.endsWith(".apps.googleusercontent.com"))
    }

    @Test
    fun `chats list displays groups and direct chats and opens create group dialog`() {
        val chats = listOf(
            ChatRoom(
                id = "uid_alice_uid_bob",
                participantIds = listOf("uid_alice", "uid_bob"),
                participantNames = mapOf("uid_alice" to "Alice", "uid_bob" to "Bob Sharma"),
                lastMessage = "See you at 5!"
            )
        )
        val groups = listOf(
            GroupChat(
                id = "grp_1",
                name = "ABHI Founders",
                adminIds = listOf("uid_alice"),
                memberIds = listOf("uid_alice", "uid_bob"),
                lastMessage = "Release tonight",
                lastSenderName = "Bob Sharma"
            )
        )
        composeTestRule.setContent {
            AbhiChatTheme {
                ChatsListScreen(
                    currentUserId = currentUid,
                    chatsState = UiState.Success(chats),
                    groupsState = UiState.Success(groups),
                    usersState = UiState.Success(sampleUsers),
                    storiesState = UiState.Success(emptyList()),
                    blockedUsers = emptyList(),
                    onOpenDirectChat = { _, _, _ -> },
                    onOpenGroupChat = { _, _ -> },
                    onStartDirectChatWithUser = {},
                    onCreateGroup = { _, _, _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ABHI Founders").assertIsDisplayed()
        composeTestRule.onNodeWithText("Bob Sharma").assertIsDisplayed()

        composeTestRule.onNodeWithTag("create_group_fab").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("group_name_input").performTextInput("Weekend Trip")
        composeTestRule.onNodeWithTag("confirm_create_group_button").assertIsDisplayed()
    }

    @Test
    fun `chat detail displays forwarded reply edited and deleted messages`() {
        val messages = listOf(
            ChatMessage(
                id = "m1",
                chatId = "c1",
                senderId = "uid_bob",
                senderName = "Bob Sharma",
                text = "Original idea",
                messageType = MessageType.TEXT.name
            ),
            ChatMessage(
                id = "m2",
                chatId = "c1",
                senderId = currentUid,
                senderName = "Alice",
                text = "Updated reply",
                replyToMessageId = "m1",
                replyToSenderName = "Bob Sharma",
                replyToText = "Original idea",
                forwarded = true,
                edited = true
            ),
            ChatMessage(
                id = "m3",
                chatId = "c1",
                senderId = currentUid,
                senderName = "Alice",
                text = "This message was deleted",
                deletedForEveryone = true
            )
        )
        composeTestRule.setContent {
            AbhiChatTheme {
                ChatDetailScreen(
                    currentUserId = currentUid,
                    chatId = "c1",
                    conversationType = "DIRECT",
                    title = "Bob Sharma",
                    recipientId = "uid_bob",
                    memberIds = listOf(currentUid, "uid_bob"),
                    messagesState = UiState.Success(messages),
                    otherUser = sampleUsers[1],
                    group = null,
                    allUsers = sampleUsers,
                    allGroups = emptyList(),
                    isBlocked = false,
                    onBack = {},
                    onOpenGroupInfo = {},
                    onStartCall = { _, _ -> },
                    onSendText = { _, _ -> },
                    onSendMedia = { _, _, _, _, _ -> },
                    onShareLocation = { _, _, _ -> },
                    onStopLiveLocation = { _, _, _ -> },
                    onEditMessage = { _, _ -> },
                    onDeleteForMe = {},
                    onDeleteForEveryone = {},
                    onForwardMessage = { _, _, _ -> },
                    onBlockUser = {},
                    onReportUser = { _, _, _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Forwarded").assertIsDisplayed()
        composeTestRule.onNodeWithText("Updated reply").assertIsDisplayed()
        composeTestRule.onNodeWithText("This message was deleted").assertIsDisplayed()
        composeTestRule.onNodeWithTag("voice_call_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("video_call_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("share_location_button").assertIsDisplayed()
    }

    @Test
    fun `updates screen renders stories and statuses`() {
        val future = System.currentTimeMillis() + 60_000_000L
        val statuses = listOf(
            StatusItem(
                id = "st1",
                userId = "uid_bob",
                userName = "Bob Sharma",
                text = "Working on ABHI CHAT!",
                expiresAtMillis = future
            )
        )
        val stories = listOf(
            StoryItem(
                id = "sr1",
                userId = "uid_bob",
                userName = "Bob Sharma",
                caption = "Evening coffee",
                overlayText = "Good Vibes",
                expiresAtMillis = future
            )
        )
        composeTestRule.setContent {
            AbhiChatTheme {
                UpdatesScreen(
                    currentUserId = currentUid,
                    myProfile = sampleUsers[0],
                    statusesState = UiState.Success(statuses),
                    statusViewsState = UiState.Success(emptyList()),
                    storiesState = UiState.Success(stories),
                    storyViewsState = UiState.Success(emptyList()),
                    onPostStatus = { _, _, _, _, _ -> },
                    onMarkStatusViewed = {},
                    onReplyToStatus = { _, _ -> },
                    onDeleteStatus = {},
                    onPostStory = { _, _, _, _, _, _ -> },
                    onMarkStoryViewed = {},
                    onReactToStory = { _, _ -> },
                    onReplyToStory = { _, _ -> },
                    onDeleteStory = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Stories").assertIsDisplayed()
        composeTestRule.onNodeWithText("Status Updates").assertIsDisplayed()
        composeTestRule.onNodeWithText("Good Vibes").assertIsDisplayed()
        composeTestRule.onNodeWithText("Working on ABHI CHAT!").assertIsDisplayed()
    }

    @Test
    fun `friends and profile privacy screens render core controls`() {
        val reqs = listOf(
            FriendRequestItem(
                id = "uid_bob_uid_alice",
                senderId = "uid_bob",
                senderName = "Bob Sharma",
                receiverId = currentUid,
                receiverName = "Alice",
                status = "PENDING"
            )
        )
        composeTestRule.setContent {
            AbhiChatTheme {
                FriendsScreen(
                    currentUserId = currentUid,
                    usersState = UiState.Success(sampleUsers),
                    friendsState = UiState.Success(emptyList<FriendEdge>()),
                    requestsState = UiState.Success(reqs),
                    blockedUsers = emptyList(),
                    targetPrivacyMap = emptyMap(),
                    onFetchTargetPrivacy = {},
                    onSendRequest = {},
                    onAcceptRequest = {},
                    onRejectRequest = {},
                    onCancelRequest = {},
                    onRemoveFriend = {},
                    onOpenChat = {},
                    onStartCall = { _, _ -> },
                    onBlockUser = {},
                    onReportUser = { _, _, _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Pending Friend Requests (1)").assertIsDisplayed()
        composeTestRule.onNodeWithTag("accept_friend_req_uid_bob_uid_alice").assertIsDisplayed()
    }

    @Test
    fun `profile privacy screen renders all privacy controls`() {
        composeTestRule.setContent {
            AbhiChatTheme {
                ProfilePrivacyScreen(
                    myProfileState = UiState.Success(sampleUsers[0]),
                    privacyState = UiState.Success(PrivacySettings(id = currentUid, userId = currentUid)),
                    blockedUsers = listOf(BlockedUser(id = "b1", blockerId = currentUid, blockedId = "u3", blockedName = "Spammer")),
                    onUpdateProfile = { _, _, _, _ -> },
                    onUpdatePrivacy = {},
                    onUnblockUser = {},
                    onSignOut = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("profile_privacy_list").performScrollToNode(hasTestTag("save_profile_button"))
        composeTestRule.onNodeWithTag("save_profile_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("profile_privacy_list").performScrollToNode(hasText("Profile Privacy Settings"))
        composeTestRule.onNodeWithText("Profile Privacy Settings").assertIsDisplayed()
        composeTestRule.onNodeWithTag("profile_privacy_list").performScrollToNode(hasTestTag("manage_blocked_users_button"))
        composeTestRule.onNodeWithTag("manage_blocked_users_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("profile_privacy_list").performScrollToNode(hasTestTag("sign_out_button"))
        composeTestRule.onNodeWithTag("sign_out_button").assertIsDisplayed()
    }
}
